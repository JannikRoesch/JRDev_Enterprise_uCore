#pragma once
#include <WiFi.h>
#include <vector>

namespace uCore {
  class WiFiController {
    public:
      enum class ConnectionMode {
        STA,
        AP,
        STA_AP
      };
      
      struct NetworkConfig {
        String ssid;
        String password;
        IPAddress staticIP;
        IPAddress gateway;
        IPAddress subnet;
      };
      
      WiFiController();
      
      void configure(ConnectionMode mode, const NetworkConfig& config);
      void addPreferredNetwork(const String& ssid, const String& password);
      void start();
      void stop();
      
      void setReconnectPolicy(bool autoReconnect, uint16_t interval);
      void handleEvents();
      
    private:
      ConnectionMode _mode;
      NetworkConfig _config;
      std::vector<std::pair<String, String>> _preferredNetworks;
      bool _autoReconnect;
      uint16_t _reconnectInterval;
      
      void _startSTA();
      void _startAP();
      void _scanAndConnect();
  };
}