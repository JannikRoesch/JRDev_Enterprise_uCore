#include "BLEManager.h"

namespace uCore {
  void BLEController::begin() {
    BLEDevice::init(_deviceName.c_str());
    _server = BLEDevice::createServer();
    _server->setCallbacks(new ServerCallbacks(_connectionCallback));
  }

  void BLEController::startAdvertising() {
    BLEAdvertising* advertising = _server->getAdvertising();
    advertising->addServiceUUID(_serviceUUID.c_str());
    advertising->setScanResponse(true);
    advertising->start();
  }

  void BLEController::ServerCallbacks::onConnect(BLEServer* pServer) {
    if(_callback) _callback(true);
  }

  void BLEController::ServerCallbacks::onDisconnect(BLEServer* pServer) {
    if(_callback) _callback(false);
    pServer->startAdvertising();
  }

  void BLEController::addCharacteristic(const String& uuid, uint32_t properties) {
    BLECharacteristic* characteristic = _currentService->createCharacteristic(
      uuid.c_str(),
      properties
    );
    _characteristics[uuid] = characteristic;
  }
}