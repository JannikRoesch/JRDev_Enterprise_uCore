#include "MQTTManager.h"

namespace uCore {
  MQTTController* MQTTController::_instance = nullptr;

  MQTTController::MQTTController() : _mqttClient(_wifiClient) {
    _instance = this;
    _mqttClient.setCallback(_mqttCallback);
  }

  void MQTTController::begin(const MQTTConfig& config) {
    _config = config;
    _mqttClient.setServer(_config.server.c_str(), _config.port);
    _reconnect();
  }

  void MQTTController::loop() {
    if(!_mqttClient.connected()) {
      _reconnect();
    }
    _mqttClient.loop();
  }

  bool MQTTController::publish(const String& topic, const String& message) {
    if(!_mqttClient.connected()) return false;
    return _mqttClient.publish(topic.c_str(), message.c_str());
  }

  bool MQTTController::subscribe(const String& topic) {
    if(!_mqttClient.connected()) return false;
    return _mqttClient.subscribe(topic.c_str());
  }

  void MQTTController::_reconnect() {
    static uint32_t lastAttempt = 0;
    const uint32_t retryInterval = 5000;

    if(millis() - lastAttempt < retryInterval) return;
    lastAttempt = millis();

    Serial.print("Verbinde mit MQTT Broker...");
    
    bool success = _mqttClient.connect(
      _config.clientID.c_str(),
      _config.username.c_str(),
      _config.password.c_str()
    );

    if(success) {
      Serial.println("verbunden!");
      if(_connectionCallback) _connectionCallback(true);
    } else {
      Serial.print("fehlgeschlagen, rc=");
      Serial.println(_mqttClient.state());
      if(_connectionCallback) _connectionCallback(false);
    }
  }

  void MQTTController::_mqttCallback(char* topic, byte* payload, unsigned int length) {
    if(_instance && _instance->_messageCallback) {
      String topicStr(topic);
      String message;
      message.reserve(length);
      for(unsigned int i=0; i<length; i++) {
        message += (char)payload[i];
      }
      _instance->_messageCallback(topicStr, message);
    }
  }

  void MQTTController::setMessageCallback(std::function<void(String, String)> callback) {
    _messageCallback = callback;
  }

  void MQTTController::setConnectionCallback(std::function<void(bool)> callback) {
    _connectionCallback = callback;
  }
}