#pragma once
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>

namespace uCore {
  class BLEController {
    public:
      struct BLEServiceConfig {
        String serviceUUID;
        String characteristicUUID;
        bool notify;
        bool indicate;
      };
      
      BLEController(const String& deviceName);
      
      void begin();
      void addService(const BLEServiceConfig& config);
      void startAdvertising();
      void stopAdvertising();
      
      void setCharacteristicValue(const String& serviceUUID, const String& characteristicUUID, const String& value);
      String getCharacteristicValue(const String& serviceUUID, const String& characteristicUUID);
      
      void setConnectionCallback(std::function<void(bool)> callback);
      
    private:
      String _deviceName;
      BLEServer* _server;
      BLEService* _currentService;
      std::map<String, BLECharacteristic*> _characteristics;
      std::function<void(bool)> _connectionCallback;
      
      class ServerCallbacks : public BLEServerCallbacks {
        public:
          ServerCallbacks(std::function<void(bool)> callback) : _callback(callback) {}
          void onConnect(BLEServer* pServer) override;
          void onDisconnect(BLEServer* pServer) override;
        private:
          std::function<void(bool)> _callback;
      };
  };
}