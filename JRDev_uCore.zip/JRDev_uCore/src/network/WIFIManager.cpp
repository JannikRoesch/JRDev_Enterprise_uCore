#include "WiFiManager.h"

namespace uCore {
  void WiFiController::configure(ConnectionMode mode, const NetworkConfig& config) {
    _mode = mode;
    _config = config;
  }

  void WiFiController::start() {
    if(_mode == ConnectionMode::AP || _mode == ConnectionMode::STA_AP) {
      _startAP();
    }
    if(_mode == ConnectionMode::STA || _mode == ConnectionMode::STA_AP) {
      _startSTA();
    }
  }

  void WiFiController::_startSTA() {
    WiFi.mode(WIFI_STA);
    
    if(_config.staticIP.isSet()) {
      WiFi.config(_config.staticIP, _config.gateway, _config.subnet);
    }
    
    WiFi.begin(_config.ssid.c_str(), _config.password.c_str());
  }

  void WiFiController::_startAP() {
    WiFi.softAPConfig(_config.apIP, _config.gateway, _config.subnet);
    WiFi.softAP(_config.apSSID.c_str(), _config.apPassword.c_str());
  }

  void WiFiController::handleEvents() {
    static wl_status_t lastStatus = WL_IDLE_STATUS;
    
    if(WiFi.status() != lastStatus) {
      lastStatus = WiFi.status();
      if(_statusCallback) {
        _statusCallback(lastStatus);
      }
    }
  }
}