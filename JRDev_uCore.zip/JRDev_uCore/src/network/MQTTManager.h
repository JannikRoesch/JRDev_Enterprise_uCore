#pragma once
#include <WiFiClient.h>
#include <PubSubClient.h>

namespace uCore {
  class MQTTController {
    public:
      struct MQTTConfig {
        String server;
        int port = 1883;
        String clientID;
        String username;
        String password;
      };
      
      MQTTController();
      
      void begin(const MQTTConfig& config);
      void loop();
      
      bool publish(const String& topic, const String& message);
      bool subscribe(const String& topic);
      
      void setMessageCallback(std::function<void(String, String)> callback);
      void setConnectionCallback(std::function<void(bool)> callback);
      
    private:
      WiFiClient _wifiClient;
      PubSubClient _mqttClient;
      MQTTConfig _config;
      std::function<void(String, String)> _messageCallback;
      std::function<void(bool)> _connectionCallback;
      
      void _reconnect();
      static void _mqttCallback(char* topic, byte* payload, unsigned int length);
  };
}