#pragma once
#include <HardwareSerial.h>

namespace uCore {
  class UARTController {
    public:
      UARTController(int txPin = -1, int rxPin = -1, int baudRate = 115200);
      
      void begin();
      void setPins(int txPin, int rxPin);
      void setBaudRate(int baudRate);
      
      size_t write(const uint8_t* data, size_t length);
      size_t read(uint8_t* buffer, size_t length);
      
      void flush();
      bool available();
      
    private:
      int _txPin;
      int _rxPin;
      int _baudRate;
      HardwareSerial _serial;
      bool _initialized = false;
      
      void _checkInitialization();
  };
}