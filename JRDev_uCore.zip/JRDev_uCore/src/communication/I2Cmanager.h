#pragma once
#include <Wire.h>

namespace uCore {
  class I2CController {
    public:
      I2CController(int sdaPin = -1, int sclPin = -1, uint32_t frequency = 100000);
      
      void begin();
      void scanDevices();
      
      bool deviceExists(uint8_t address);
      bool writeByte(uint8_t address, uint8_t reg, uint8_t value);
      uint8_t readByte(uint8_t address, uint8_t reg);
      
      void setFrequency(uint32_t frequency);
      void setPins(int sdaPin, int sclPin);
      
    private:
      int _sdaPin;
      int _sclPin;
      uint32_t _frequency;
      bool _initialized = false;
      
      void _checkInitialization();
  };
}