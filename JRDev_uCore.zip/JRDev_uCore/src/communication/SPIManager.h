#pragma once
#include <SPI.h>

namespace uCore {
  class SPIController {
    public:
      SPIController(int misoPin = -1, int mosiPin = -1, int sclkPin = -1, int csPin = -1);
      
      void begin();
      void setFrequency(uint32_t frequency);
      void setDataMode(uint8_t mode);
      
      uint8_t transfer(uint8_t data);
      void transfer(uint8_t* data, size_t length);
      
      void setChipSelect(int pin);
      void select();
      void deselect();
      
    private:
      int _misoPin;
      int _mosiPin;
      int _sclkPin;
      int _csPin;
      uint32_t _frequency;
      uint8_t _dataMode;
      bool _initialized = false;
      
      void _checkInitialization();
  };
}