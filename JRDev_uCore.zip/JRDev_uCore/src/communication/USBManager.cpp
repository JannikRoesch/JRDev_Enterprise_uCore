#include "USBManager.h"

namespace uCore {
  USBController::USBController() : _currentMode(Mode::CDC) {}

  void USBController::begin(Mode mode) {
    _currentMode = mode;
    
    switch(mode) {
      case Mode::HID:
        _initializeHID();
        break;
      case Mode::CDC:
        _initializeCDC();
        break;
      case Mode::MSC:
        _initializeMSC();
        break;
      case Mode::Composite:
        _initializeHID();
        _initializeCDC();
        break;
    }
    
    USB.begin();
  }

  void USBController::_initializeHID() {
    static const uint8_t reportDescriptor[] = {
      // Beispiel-Report-Descriptor
      0x06, 0x00, 0xFF,  // USAGE_PAGE (Vendor Defined)
      0x09, 0x01,        // USAGE (Vendor Usage 1)
      0xA1, 0x01,        // COLLECTION (Application)
      0x15, 0x00,        // LOGICAL_MINIMUM (0)
      0x26, 0xFF, 0x00,  // LOGICAL_MAXIMUM (255)
      0x75, 0x08,        // REPORT_SIZE (8)
      0x95, 0x40,        // REPORT_COUNT (64)
      0x09, 0x01,        // USAGE (Vendor Usage 1)
      0x81, 0x02,        // INPUT (Data,Var,Abs)
      0x09, 0x01,        // USAGE (Vendor Usage 1)
      0x91, 0x02,        // OUTPUT (Data,Var,Abs)
      0xC0               // END_COLLECTION
    };
    
    _hid.setReportDescriptor(reportDescriptor, sizeof(reportDescriptor));
    _hid.begin();
  }

  void USBController::_initializeCDC() {
    _cdc.begin();
  }

  void USBController::_initializeMSC() {
    // MSC-Initialisierung
  }

  void USBController::sendHIDReport(const uint8_t* report, size_t length) {
    _hid.SendReport(0, report, length);
  }

  bool USBController::receiveHIDReport(uint8_t* buffer, size_t length) {
    return _hid.RecvReport(0, buffer, length) > 0;
  }

  size_t USBController::writeCDC(const uint8_t* buffer, size_t size) {
    return _cdc.write(buffer, size);
  }

  size_t USBController::readCDC(uint8_t* buffer, size_t size) {
    return _cdc.readBytes(buffer, size);
  }

  bool USBController::isMSCConnected() const {
    return USB.MSCConnected();
  }
}