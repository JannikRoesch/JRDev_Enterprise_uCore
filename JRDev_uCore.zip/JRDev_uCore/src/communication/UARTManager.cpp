#include "UARTManager.h"

namespace uCore {
  UARTController::UARTController(int txPin, int rxPin, int baudRate)
    : _txPin(txPin), _rxPin(rxPin), _baudRate(baudRate), _serial(1) {}

  void UARTController::begin() {
    if(_txPin != -1 && _rxPin != -1) {
      _serial.begin(_baudRate, SERIAL_8N1, _rxPin, _txPin);
    } else {
      _serial.begin(_baudRate);
    }
    _initialized = true;
  }

  void UARTController::setPins(int txPin, int rxPin) {
    _txPin = txPin;
    _rxPin = rxPin;
    if(_initialized) {
      begin();
    }
  }

  void UARTController::setBaudRate(int baudRate) {
    _baudRate = baudRate;
    if(_initialized) {
      _serial.begin(_baudRate);
    }
  }

  size_t UARTController::write(const uint8_t* data, size_t length) {
    _checkInitialization();
    return _serial.write(data, length);
  }

  size_t UARTController::read(uint8_t* buffer, size_t length) {
    _checkInitialization();
    return _serial.readBytes(buffer, length);
  }

  void UARTController::flush() {
    _checkInitialization();
    _serial.flush();
  }

  bool UARTController::available() {
    _checkInitialization();
    return _serial.available();
  }

  void UARTController::_checkInitialization() {
    if(!_initialized) {
      Serial.println("UART not initialized!");
      begin();
    }
  }
}