#pragma once
#include <USB.h>
#include <USBCDC.h>
#include <USBHID.h>

namespace uCore {
  class USBController {
    public:
      enum class Mode {
        HID,
        CDC,
        MSC,
        Composite
      };
      
      USBController();
      
      void begin(Mode mode);
      void end();
      
      // HID-Funktionen
      void sendHIDReport(const uint8_t* report, size_t length);
      bool receiveHIDReport(uint8_t* buffer, size_t length);
      
      // CDC-Funktionen
      size_t writeCDC(const uint8_t* buffer, size_t size);
      size_t readCDC(uint8_t* buffer, size_t size);
      
      // MSC-Funktionen
      bool isMSCConnected() const;
      
    private:
      Mode _currentMode;
      USBCDC _cdc;
      USBHID _hid;
      
      void _initializeHID();
      void _initializeCDC();
      void _initializeMSC();
  };
}