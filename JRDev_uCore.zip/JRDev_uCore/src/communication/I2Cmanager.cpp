#include "I2CManager.h"

namespace uCore {
  I2CController::I2CController(int sdaPin, int sclPin, uint32_t frequency)
    : _sdaPin(sdaPin), _sclPin(sclPin), _frequency(frequency) {}

  void I2CController::begin() {
    if(_sdaPin != -1 && _sclPin != -1) {
      Wire.begin(_sdaPin, _sclPin);
    } else {
      Wire.begin();
    }
    Wire.setClock(_frequency);
    _initialized = true;
  }

  void I2CController::scanDevices() {
    _checkInitialization();
    for(uint8_t address = 1; address < 127; address++) {
      Wire.beginTransmission(address);
      if(Wire.endTransmission() == 0) {
        Serial.printf("Device found at 0x%02X\n", address);
      }
    }
  }

  bool I2CController::deviceExists(uint8_t address) {
    _checkInitialization();
    Wire.beginTransmission(address);
    return Wire.endTransmission() == 0;
  }

  bool I2CController::writeByte(uint8_t address, uint8_t reg, uint8_t value) {
    _checkInitialization();
    Wire.beginTransmission(address);
    Wire.write(reg);
    Wire.write(value);
    return Wire.endTransmission() == 0;
  }

  uint8_t I2CController::readByte(uint8_t address, uint8_t reg) {
    _checkInitialization();
    Wire.beginTransmission(address);
    Wire.write(reg);
    Wire.endTransmission(false);
    Wire.requestFrom(address, (uint8_t)1);
    return Wire.read();
  }

  void I2CController::setFrequency(uint32_t frequency) {
    _frequency = frequency;
    if(_initialized) {
      Wire.setClock(_frequency);
    }
  }

  void I2CController::setPins(int sdaPin, int sclPin) {
    _sdaPin = sdaPin;
    _sclPin = sclPin;
    if(_initialized) {
      begin();
    }
  }

  void I2CController::_checkInitialization() {
    if(!_initialized) {
      Serial.println("I2C not initialized!");
      begin();
    }
  }
}