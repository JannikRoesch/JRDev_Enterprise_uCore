#include "SPIManager.h"

namespace uCore {
  SPIController::SPIController(int misoPin, int mosiPin, int sclkPin, int csPin)
    : _misoPin(misoPin), _mosiPin(mosiPin), _sclkPin(sclkPin), _csPin(csPin) {}

  void SPIController::begin() {
    if(_misoPin != -1 && _mosiPin != -1 && _sclkPin != -1) {
      SPI.begin(_sclkPin, _misoPin, _mosiPin);
    } else {
      SPI.begin();
    }
    if(_csPin != -1) {
      pinMode(_csPin, OUTPUT);
      digitalWrite(_csPin, HIGH);
    }
    _initialized = true;
  }

  void SPIController::setFrequency(uint32_t frequency) {
    _frequency = frequency;
    if(_initialized) {
      SPI.setFrequency(_frequency);
    }
  }

  void SPIController::setDataMode(uint8_t mode) {
    _dataMode = mode;
    if(_initialized) {
      SPI.setDataMode(_dataMode);
    }
  }

  uint8_t SPIController::transfer(uint8_t data) {
    _checkInitialization();
    return SPI.transfer(data);
  }

  void SPIController::transfer(uint8_t* data, size_t length) {
    _checkInitialization();
    SPI.transfer(data, length);
  }

  void SPIController::setChipSelect(int pin) {
    _csPin = pin;
    if(_initialized) {
      pinMode(_csPin, OUTPUT);
      digitalWrite(_csPin, HIGH);
    }
  }

  void SPIController::select() {
    _checkInitialization();
    if(_csPin != -1) {
      digitalWrite(_csPin, LOW);
    }
  }

  void SPIController::deselect() {
    _checkInitialization();
    if(_csPin != -1) {
      digitalWrite(_csPin, HIGH);
    }
  }

  void SPIController::_checkInitialization() {
    if(!_initialized) {
      Serial.println("SPI not initialized!");
      begin();
    }
  }
}