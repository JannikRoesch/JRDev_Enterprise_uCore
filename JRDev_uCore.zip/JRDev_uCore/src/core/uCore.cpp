#include "uCore.h"

namespace uCore {
  CoreSystem::CoreSystem() : _cpuFrequency(240) {}
  
  CoreSystem::CoreSystem(uint32_t cpuFrequency) : _cpuFrequency(cpuFrequency) {}

  void CoreSystem::begin() {
    _checkHardware();
    setCPUFrequency(_cpuFrequency);
    _initializeWatchdog();
  }

  void CoreSystem::setCPUFrequency(uint32_t frequency) {
    if(frequency != _cpuFrequency) {
      setCpuFrequencyMhz(frequency);
      _cpuFrequency = frequency;
    }
  }

  void CoreSystem::registerErrorCallback(std::function<void(int)> callback) {
    _errorCallback = callback;
  }

  void CoreSystem::systemRestart(uint32_t restartDelayMS) {
    if (Serial.available()) {
      Serial.println("System rebooting NOW!");
      // sPrint("System rebooting NOW.", 3, true);
    }
    //saveAllDataHandler needed before reboot
    delay(restartDelayMS);
    ESP.restart();
    while (true) {}
  }
  
  String CoreSystem::getChipID() {
    uint64_t chipid = ESP.getEfuseMac();
    return String((uint32_t)(chipid>>32), HEX) + String((uint32_t)chipid, HEX);
  }

  String CoreSystem::getFlashInfo() {
    return String(ESP.getFlashChipSize() / (1024 * 1024)) + "MB " +
           String(ESP.getFlashChipSpeed() / 1000000) + "MHz";
  }

  void CoreSystem::enableSystemMonitor(bool enable) {
    if(enable) {
      // System-Monitoring initialisieren
    } else {
      // Monitoring deaktivieren
    }
  }

  void CoreSystem::_checkHardware() {
    // Hardware-Spezifische Checks
    if(!psramFound()) {
      if(_errorCallback) _errorCallback(1);
    }
  }

  void CoreSystem::_initializeWatchdog() {
    // Watchdog-Timer konfigurieren
    esp_task_wdt_init(30, true);
  }
}