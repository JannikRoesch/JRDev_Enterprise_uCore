#pragma once
#include <Arduino.h>
#include <functional>

namespace uCore {
  class CoreSystem {
    public:
      // Konstruktoren
      CoreSystem();
      explicit CoreSystem(uint32_t cpuFrequency);
      
      // Systemfunktionen
      void begin();
      void setCPUFrequency(uint32_t frequency);
      void registerErrorCallback(std::function<void(int)> callback);
      void systemRestart(uint32_t restartDelayMS = 2000);
      
      // Hardware-Informationen
      static String getChipID();
      static String getFlashInfo();
      
      // Debug-Funktionen
      void enableSystemMonitor(bool enable);
      
    private:
      uint32_t _cpuFrequency;
      std::function<void(int)> _errorCallback;
      
      void _checkHardware();
      void _initializeWatchdog();
  };
}