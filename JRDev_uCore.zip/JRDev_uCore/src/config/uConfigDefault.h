// Geräte-Informationen
#define DEVICE_VERSION 1.0.0

// Systemeinstellungen
#define CPU_FREQUENCY 240
#define WATCHDOG_TIMEOUT 30

// Netzwerk/WiFi Einstellungen
#define NET_WIFI_MODE "STA"                 // STA || AP
#define NET_WIFI_AP_SSID "APwifiSSID"
#define NWT_WIFI_AP_PASS "APwifiPassword"
#define NET_WIFi_AP_HOSTNAME "esp32-device"
#define NET_WIFI_AP_IP 192.168.4.1
#define NET_WIFI_STA_SSID "STAwifiSSID"
#define NWT_WIFI_STA_PASS "STAwifiPassword"
#define NET_WIFi_STA_HOSTNAME "esp32-device"
#define NET_WIFI_STA_MODE "STATIC"          // STATIC || DHCP
#define NET_WIFI_STA_IP 192.168.1.100       // Dfeniere wenn NET_WIFI_STA_MODE "STATIC"
#define NET_WIFI_STA_GATEWAY 192.168.1.1    // Dfeniere wenn NET_WIFI_STA_MODE "STATIC"
#define NET_WIFI_STA_DNS 192.168.1.1        // Dfeniere wenn NET_WIFI_STA_MODE "STATIC"
#define NET_WIFI_STA_MASK 255.255.255.0     // Dfeniere wenn NET_WIFI_STA_MODE "STATIC"

// MQTT Einstellungen
#define NET_MQTT_SERVER 192.168.1.200
#define NET_MQTT_USER "mqttUser"
#define NET_MQTT_USER_PASS "userPassword"
#define NET_MQTT_CLIENT "esp32_device"
#define NET_MQTT_PREFIX "mqttPrefix"
#define NET_MQTT_TOPIC "mqttTopic"
#define NET_MQTT_FULL_TOPIC NET_MQTT_PREFIX + NET_MQTT_TOPIC

// OTA-Einstellungen
#define UTIL_OTA_HOSTNAME "esp32-device"
#define UTIL_OTA_PASSWORD "otaPassword"

// OLED-Display Parameter
#define OLED_SCRREN_WIDTH 128
#define OLED_SCRREN_HEIGHT 64

// UART Einstellungen
#define COM_SERIAL_UART_PIN_TX -1
#define COM_SERIAL_UART_PIN_RX -1

// Web-Serial Einstellungen
#define COM_SERIAL_WEB_PIN_TX -1
#define COM_SERIAL_WEB_PIN_RX -1

// USB Einstellungen
#define COM_USB_MODE "HID"                      // HID || CDC || MSC || OTG
#define COM_USB_HID_TYPE "KEYVOARD-MOUSE"       // KEYBOARD || MOUSE || KEYBOARD-MOUSE || CONTROLLER || CUSTOM

// Power-Manager Einstellungen
#define POWER_SAVE_MODE "DEEPSLEEP"         // LIGHTSLEEP || DEEPSLEEP || HIBERNATE
#define POWER_SAVE_WAKEUP_SRC "TIMER"       // TIMER || PIN || TIMER-PIN
#define POWER_SAVE_WAKEUP_TIME 10000        // Wakup-Timer in Millisekunden
#define POWER_SAVE_WAKEUP_PIN -1            // Defeniere wenn "POWER_SAVE_WAKEUP_SRC" auf "PIN" or "TIMER-PIN" gesetzt ist, ansonsten setze "-1" für Standard-Wert "Keinen Pin definiert" 