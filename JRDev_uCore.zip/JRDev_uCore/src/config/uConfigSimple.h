// Minimal-Konfiguration für Einsteiger
#define CPU_FREQUENCY 160
#define WATCHDOG_TIMEOUT 60

#define NET_WIFI_SSID "myWifi"
#define NET_WIFI_PASS "password"
#define NET_WIFI_MODE "DHCP"

#define UTIL_OTA_HOSTNAME "esp32-device"