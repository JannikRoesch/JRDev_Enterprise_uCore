// Systemeinstellungen
#pragma once

// Hardware-Konfiguration
#define HW_LED_BUILTIN 2                 // GPIO für Built-in LED
#define HW_BUTTON_GPIO 0                 // Boot-Button
#define HW_SENSOR_I2C_SCL 22             // Default I2C Pins
#define HW_SENSOR_I2C_SDA 21

// Debugging
#define DEBUG_SERIAL_BAUD 115200
#define DEBUG_ENABLE_TELNET true         // Telnet-Server aktivieren
#define DEBUG_TELNET_PORT 23

// Energieverwaltung
#define POWER_BATTERY_ADC_PIN 34         // ADC Pin für Batteriemessung
#define POWER_BATTERY_R1 10000           // Spannungsteiler R1
#define POWER_BATTERY_R2 10000           // Spannungsteiler R2

// Sicherheit
#define SECURITY_OTA_PASSWORD "secure123"
#define SECURITY_WIFI_PSK "wpa2-enterprise" // WPA2|WPA3|WEP|OWE

// Peripherie
#define PERIPH_NEOPIXEL_PIN 13           // WS2812 Data Pin
#define PERIPH_NEOPIXEL_COUNT 8

// Sensorkonfiguration
#define SENSOR_BME680_ENABLED true
#define SENSOR_BME680_I2C_ADDR 0x76

// Erweiterte Netzwerkeinstellungen
#define NET_WIFI_SCAN_METHOD "FAST"      // FAST|FULL
#define NET_WIFI_SORT_METHOD "RSSI"      // RSSI|SSID
#define NET_WIFI_FAST_RECONNECT true

// MQTT QoS Einstellungen
#define NET_MQTT_QOS 1                   // 0|1|2
#define NET_MQTT_RETAIN true

// OTA Update
#define UTIL_OTA_PORT 3232
#define UTIL_OTA_MDNS true

// Dateisystem
#define FS_FORMAT_ON_FAIL true           // Automatisches Format bei Fehlern
#define FS_MAX_FILES 10

// USB Host Einstellungen
#define USB_HOST_DP_PIN 19
#define USB_HOST_DM_PIN 20
#define USB_HOST_MAX_DEVICES 2

// GPIO Defaults
#define GPIO_SAFE_MODE true              // Schützt GPIO vor Kurzschlüssen
#define GPIO_PULL_DEFAULT "UP"           // UP|DOWN|NONE