// Experten-Konfiguration mit allen Optionen
#pragma once

// Erweiterte Systemeinstellungen
#define CPU_FREQUENCY 240                 // 80|160|240 MHz
#define WATCHDOG_TIMEOUT 30               // Sekunden
#define DEBUG_LEVEL 3                     // 0-4 (0=Kein Debug)
#define SERIAL_BAUDRATE 115200

// Erweiterte WiFi-Einstellungen
#define NET_WIFI_MODE "STA_AP"            // STA|AP|STA_AP
#define NET_WIFI_AP_CHANNEL 6
#define NET_WIFI_AP_MAX_CONN 4
#define NET_WIFI_POWER_SAVE true
#define NET_WIFI_FAST_CONNECT true

// Enterprise WiFi Unterstützung
#define NET_WIFI_EAP_IDENTITY "user@domain"
#define NET_WIFI_EAP_USERNAME "username"
#define NET_WIFI_EAP_PASSWORD "password"

// MQTT Sicherheit
#define NET_MQTT_TLS false
#define NET_MQTT_CERT_FILE "/mqtt_cert.pem"
#define NET_MQTT_PORT 8883

// Low-Power Mode
#define POWER_UNDERVOLTAGE_LIMIT 3.3      // Abschaltspannung in V (Volt)
#define POWER_BATTERY_CAPACITY 2000       // Batterie-Kapazitöt in mAh (Milli-Amperestunden)