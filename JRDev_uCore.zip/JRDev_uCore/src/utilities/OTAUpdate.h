#pragma once
#include <ArduinoOTA.h>

namespace uCore {
  class OTAHandler {
    public:
      struct OTACallbacks {
        std::function<void()> startCallback;
        std::function<void(unsigned int, unsigned int)> progressCallback;
        std::function<void()> endCallback;
        std::function<void(ota_error_t)> errorCallback;
      };
      
      void initialize(const String& hostname, const OTACallbacks& callbacks);
      void enableMDNS(bool enable);
      void handle();
      
    private:
      OTACallbacks _callbacks;
      bool _mdnsEnabled;
      
      void _setupEventHandlers();
  };
}