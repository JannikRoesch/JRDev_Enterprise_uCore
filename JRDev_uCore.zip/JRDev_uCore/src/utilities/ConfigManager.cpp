#include "ConfigManager.h"
#include <LittleFS.h>

namespace uCore {
  bool ConfigManager::loadFromFile(const String& filename) {
    if(!LittleFS.begin()) return false;
    
    File file = LittleFS.open(filename, "r");
    if(!file) return false;

    while(file.available()) {
      String line = file.readStringUntil('\n');
      line.trim();
      _parseLine(line);
    }
    
    file.close();
    return true;
  }

  bool ConfigManager::saveToFile(const String& filename) {
    File file = LittleFS.open(filename, "w");
    if(!file) return false;

    for(auto& entry : _configValues) {
      String line = _escapeString(entry.first) + "=" + _escapeString(entry.second.value) + "\n";
      file.print(line);
    }
    
    file.close();
    return true;
  }

  void ConfigManager::_parseLine(const String& line) {
    int delimiterIndex = line.indexOf('=');
    if(delimiterIndex > 0) {
      String key = line.substring(0, delimiterIndex);
      String value = line.substring(delimiterIndex + 1);
      _configValues[key] = {_unescapeString(value), true};
    }
  }

  String ConfigManager::_escapeString(const String& str) const {
    String escaped;
    for(unsigned int i = 0; i < str.length(); i++) {
      char c = str[i];
      if(c == '\\' || c == '=' || c == '\n') {
        escaped += '\\';
      }
      escaped += c;
    }
    return escaped;
  }

  String ConfigManager::_unescapeString(const String& str) const {
    String unescaped;
    bool escape = false;
    for(unsigned int i = 0; i < str.length(); i++) {
      char c = str[i];
      if(escape) {
        unescaped += c;
        escape = false;
      } else if(c == '\\') {
        escape = true;
      } else {
        unescaped += c;
      }
    }
    return unescaped;
  }
}