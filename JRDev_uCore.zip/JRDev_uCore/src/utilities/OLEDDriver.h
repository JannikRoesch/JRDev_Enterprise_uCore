#pragma once
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

namespace uCore {
  class OLEDDisplay {
    public:
      OLEDDisplay(int width = 128, int height = 64, int i2cAddress = 0x3C);
      
      void begin();
      void clear();
      void display();
      
      void setTextSize(uint8_t size);
      void setTextColor(uint16_t color);
      void setCursor(int16_t x, int16_t y);
      void print(const String& text);
      
      void drawPixel(int16_t x, int16_t y, uint16_t color);
      void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color);
      void drawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
      
    private:
      int _width;
      int _height;
      int _i2cAddress;
      Adafruit_SSD1306 _display;
      bool _initialized = false;
      
      void _checkInitialization();
  };
}