#pragma once
#include <Arduino.h>
#include <map>

namespace uCore {
  class ConfigManager {
    public:
      struct ConfigValue {
        String value;
        bool isSet;
      };
      
      bool loadFromFile(const String& filename = "/config.cfg");
      bool saveToFile(const String& filename = "/config.cfg");
      
      void setValue(const String& key, const String& value);
      String getValue(const String& key, const String& defaultValue = "");
      
      bool hasKey(const String& key) const;
      void removeKey(const String& key);
      
    private:
      std::map<String, ConfigValue> _configValues;
      
      bool _parseLine(const String& line);
      String _escapeString(const String& str) const;
      String _unescapeString(const String& str) const;
  };
}