#include "WEBSerial.h"

namespace uCore {
  WebSerialController::WebSerialController() : _server(80) {}

  void WebSerialController::begin(const String& hostname) {
    _hostname = hostname;
    
    if(!MDNS.begin(_hostname.c_str())) {
      Serial.println("mDNS Fehler!");
    }
    
    _server.on("/", HTTP_GET, [this](){ _handleRoot(); });
    _server.on("/webserial", HTTP_GET, [this](){ _handleWebSocket(); });
    _server.onNotFound([this](){ _handleNotFound(); });

    _webSocket.begin();
    _webSocket.onEvent([this](uint8_t num, WStype_t type, uint8_t* payload, size_t length){
      if(type == WStype_TEXT && _messageCallback) {
        String msg((char*)payload);
        _messageCallback(msg);
      }
    });

    _server.begin();
    MDNS.addService("http", "tcp", 80);
  }

  void WebSerialController::_handleRoot() {
    String html = R"(
      <html><body>
        <div id="output"></div>
        <input type="text" id="input">
        <button onclick="send()">Send</button>
        <script>
          var ws = new WebSocket('ws://' + location.hostname + ':81/webserial');
          ws.onmessage = function(e) { 
            document.getElementById('output').innerHTML += e.data + '<br>';
          };
          function send() {
            ws.send(document.getElementById('input').value);
          }
        </script>
      </body></html>
    )";
    _server.send(200, "text/html", html);
  }

  void WebSerialController::print(const String& text) {
    _webSocket.broadcastTXT(text);
  }
}