#include "OLEDDriver.h"

namespace uCore {
  OLEDDisplay::OLEDDisplay(int width, int height, int i2cAddress) 
    : _width(width), _height(height), _i2cAddress(i2cAddress),
      _display(width, height, &Wire, -1) {}

  void OLEDDisplay::begin() {
    if(!_display.begin(SSD1306_SWITCHCAPVCC, _i2cAddress)) {
      Serial.println("OLED nicht gefunden!");
      return;
    }
    _display.clearDisplay();
    _display.setTextColor(SSD1306_WHITE);
    _initialized = true;
  }

  void OLEDDisplay::drawProgressBar(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t progress) {
    _checkInitialization();
    _display.drawRect(x, y, w, h, SSD1306_WHITE);
    _display.fillRect(x + 1, y + 1, (w - 2) * progress / 100, h - 2, SSD1306_WHITE);
  }

  void OLEDDisplay::drawGraph(int16_t x, int16_t y, int16_t width, int16_t height, float* data, size_t length) {
    _checkInitialization();
    float maxVal = *std::max_element(data, data + length);
    for(size_t i = 0; i < length; i++) {
      int16_t barHeight = map(data[i], 0, maxVal, 0, height);
      _display.drawLine(x + i, y + height, x + i, y + height - barHeight, SSD1306_WHITE);
    }
  }

  void OLEDDisplay::displayBitmap(const uint8_t* bitmap, size_t size) {
    _checkInitialization();
    _display.drawBitmap(0, 0, bitmap, _width, _height, SSD1306_WHITE);
  }

  void OLEDDisplay::setContrast(uint8_t contrast) {
    _checkInitialization();
    _display.ssd1306_command(SSD1306_SETCONTRAST);
    _display.ssd1306_command(contrast);
  }
}