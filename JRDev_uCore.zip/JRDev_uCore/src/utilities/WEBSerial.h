#pragma once
#include <WebServer.h>
#include <ESPmDNS.h>

namespace uCore {
  class WebSerialController {
    public:
      WebSerialController();
      
      void begin(const String& hostname);
      void loop();
      
      void print(const String& text);
      void println(const String& text);
      
      void setMessageCallback(std::function<void(String)> callback);
      
    private:
      WebServer _server;
      String _hostname;
      std::function<void(String)> _messageCallback;
      
      void _handleRoot();
      void _handleWebSocket();
      void _handleNotFound();
  };
}