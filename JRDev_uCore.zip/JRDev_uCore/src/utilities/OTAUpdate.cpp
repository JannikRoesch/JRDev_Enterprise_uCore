#include "OTAUpdate.h"
#include <ArduinoOTA.h>

namespace uCore {
  void OTAHandler::initialize(const String& hostname, const OTACallbacks& callbacks) {
    ArduinoOTA.setHostname(hostname.c_str());
    
    ArduinoOTA.onStart([callbacks]() {
      String type = ArduinoOTA.getCommand() == U_FLASH ? "sketch" : "filesystem";
      if(callbacks.startCallback) callbacks.startCallback();
    });

    ArduinoOTA.onProgress([callbacks](unsigned int progress, unsigned int total) {
      if(callbacks.progressCallback) callbacks.progressCallback(progress, total);
    });

    ArduinoOTA.onEnd([callbacks]() {
      if(callbacks.endCallback) callbacks.endCallback();
    });

    ArduinoOTA.onError([callbacks](ota_error_t error) {
      if(callbacks.errorCallback) callbacks.errorCallback(error);
    });

    ArduinoOTA.begin();
  }

  void OTAHandler::handle() {
    ArduinoOTA.handle();
  }
}