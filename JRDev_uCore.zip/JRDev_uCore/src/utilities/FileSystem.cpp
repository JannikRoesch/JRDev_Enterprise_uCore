#include "FileSystem.h"
#include <LittleFS.h>

namespace uCore {
  bool FileSystem::begin(bool formatOnFail) {
    if(!LittleFS.begin(formatOnFail)) {
      if(formatOnFail) {
        LittleFS.format();
        return LittleFS.begin();
      }
      return false;
    }
    return true;
  }

  File FileSystem::open(const String& path, FileMode mode) {
    const char* modeStr = "";
    switch(mode) {
      case FileMode::READ: modeStr = "r"; break;
      case FileMode::WRITE: modeStr = "w"; break;
      case FileMode::APPEND: modeStr = "a"; break;
    }
    return LittleFS.open(path, modeStr);
  }

  bool FileSystem::exists(const String& path) {
    return LittleFS.exists(path);
  }

  bool FileSystem::format() {
    return LittleFS.format();
  }
}