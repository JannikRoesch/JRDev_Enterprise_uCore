#pragma once
#include <LittleFS.h>

namespace uCore {
  class FileSystem {
    public:
      enum class FileMode {
        READ,
        WRITE,
        APPEND
      };
      
      bool begin(bool formatOnFail = false);
      File open(const String& path, FileMode mode);
      bool exists(const String& path);
      bool remove(const String& path);
      bool format();
      
      void setAutoFormat(bool enable) { _autoFormat = enable; }
      
    private:
      bool _autoFormat = false;
      bool _checkMount();
  };
}