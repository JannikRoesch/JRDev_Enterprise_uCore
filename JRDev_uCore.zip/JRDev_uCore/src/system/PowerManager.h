#pragma once
#include <esp_sleep.h>

namespace uCore {
  class PowerController {
    public:
      enum class SleepMode {
        LightSleep,
        DeepSleep,
        Hibernate
      };
      
      PowerController();
      
      void setSleepMode(SleepMode mode);
      void enableWakeupTimer(uint64_t timeInSeconds);
      void enableWakeupPin(gpio_num_t pin, int level);
      
      void enterSleep();
      void wakeup();
      
      float getBatteryLevel();
      void enablePowerSaveMode(bool enable);
      
    private:
      SleepMode _sleepMode;
      uint64_t _sleepDuration;
      gpio_num_t _wakeupPin;
      int _wakeupLevel;
      
      void _configureSleep();
  };
}