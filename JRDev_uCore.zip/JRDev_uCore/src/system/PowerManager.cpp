#include "PowerManager.h"

namespace uCore {
  PowerController::PowerController() : 
    _sleepMode(SleepMode::LightSleep),
    _sleepDuration(0),
    _wakeupPin(GPIO_NUM_MAX) {}

  void PowerController::enableBrownoutDetection(bool enable) {
    if(enable) {
      esp_sleep_enable_brownout_detection_wakeup();
    } else {
      esp_sleep_disable_brownout_detection_wakeup();
    }
  }
  
  void PowerController::setVoltageRegulatorMode(VoltageRegulatorMode mode) {
    switch(mode) {
      case VoltageRegulatorMode::LDO:
        // LDO-Modus konfigurieren
        break;
      case VoltageRegulatorMode::DCDC:
        // DCDC-Konverter aktivieren
        break;
    }
  }

  void PowerController::calibrateADC() {
    esp_adc_cal_characterize(
      ADC_UNIT_1,
      ADC_ATTEN_DB_11,
      ADC_WIDTH_BIT_12,
      1100,  // Default Vref
      &_adcChars
    );
  }

  float PowerController::readPreciseVoltage(int pin) {
    uint32_t raw = analogRead(pin);
    return esp_adc_cal_raw_to_voltage(raw, &_adcChars) / 1000.0f;
  }
  
  void PowerController::setSleepMode(SleepMode mode) {
    _sleepMode = mode;
    _configureSleep();
  }

  void PowerController::enableWakeupTimer(uint64_t timeInSeconds) {
    _sleepDuration = timeInSeconds * 1000000;
    esp_sleep_enable_timer_wakeup(_sleepDuration);
  }

  void PowerController::enableWakeupPin(gpio_num_t pin, int level) {
    _wakeupPin = pin;
    _wakeupLevel = level;
    gpio_wakeup_enable(pin, level ? GPIO_INTR_HIGH_LEVEL : GPIO_INTR_LOW_LEVEL);
    esp_sleep_enable_gpio_wakeup();
  }

  void PowerController::enterSleep() {
    esp_light_sleep_start();
    if(_sleepMode == SleepMode::DeepSleep) {
      esp_deep_sleep_start();
    }
  }

  float PowerController::getBatteryLevel() {
    // Implementierung batteriespezifischer Messungen
    return 3.7f; // Beispielwert
  }

  void PowerController::_configureSleep() {
    if(_sleepMode == SleepMode::DeepSleep) {
      esp_sleep_pd_config(ESP_PD_DOMAIN_RTC_PERIPH, ESP_PD_OPTION_OFF);
    } else {
      esp_sleep_pd_config(ESP_PD_DOMAIN_RTC_PERIPH, ESP_PD_OPTION_ON);
    }
  }

  void PowerController::enablePowerSaveMode(bool enable) {
    if(enable) {
      setCPUFrequency(80);
      WiFi.setSleep(true);
    } else {
      setCPUFrequency(240);
      WiFi.setSleep(false);
    }
  }
}