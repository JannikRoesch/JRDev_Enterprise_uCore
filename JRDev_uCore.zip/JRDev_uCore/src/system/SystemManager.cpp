#include "SystemManager.h"

namespace uCore {
  bool SysCTL::begin(bool systemDebug) {
    if(!systemDebug) {
        getChipID();
        getRestartInfo(); 
        getCPUInfo(); 
        getNetworkInfo();
        getFlashInfo(); 
        getDevInfo(); 
        getVersions();
        return true;
    }
    return false;
  }
  
  String CoreSystem::getChipID() {
    uint64_t chipid = ESP.getEfuseMac();
    return String((uint32_t)(chipid>>32), HEX) + String((uint32_t)chipid, HEX);
  }
  
  String CoreSystem::getRestartInfo() {
    return String("Restart-Reason:        " + ESP.getResetReason());
  }
  
  String CoreSystem::getCPUInfo() {
    return String("CPU-Frequence:         " + ESP.getCpuFreqMHz() "MHz") + 
           String("CPU Circle-Count:      " + ESP.getCycleCount());
  }
  
  String CoreSystem::getNetworkInfo() {
    return String("Network MAC:           " + WiFi.macAddress());
  }
  
  String CoreSystem::getFlashInfo() {
    return String("Flash-ID:              " + ESP.getFlashChipId()) + 
           String("Flash-Real-Size:       " + ESP.getFlashChipRealSize() / (1024 * 1024)) + "MB " + 
           String("Flash-Size:            " + ESP.getFlashChipSize() / (1024 * 1024)) + "MB " +
           String("Flash-Speed:           " + ESP.getFlashChipSpeed() / 1000000) + "MHz";
  }

  String CoreSystem::getDevInfo() {
    return String("CPU-Frequence:         " + ESP.getCpuFreqMHz() "MHz ") + 
           String("Heap-Free:             " + ESP.getFreeHeap() / (1024 * 1024)) + "MB " + 
           Szring("Heap-Fragmentation:    " + ESP.getHeapFragmentation()) + "% " + 
           String("Heap-Free Block-Size:  " + ESP.getMaxFreeBlockSize() / (1024 * 1024)) + "MB " + 
           String("Sketch-Size:           " + ESP.getSketchSize() / (1024 * 1024)) + "MB " +
           String("Free Sketch-Space:     " + ESP.getFreeSketchSpace() / 1000000) + "MB";
  }

  String CoreSystem::getVersions() {
    return String("Core-Version:          " + ESP.getCoreVersion()) + 
           String("SDK-Version:           " + ESP.getSdkVersion());
  }
}