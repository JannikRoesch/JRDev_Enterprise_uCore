#include "TaskManager.h"

namespace uCore {
  template<typename T>
  void ManagedTask<T>::start(T* context) {
    if(_taskHandle != nullptr) return;
    
    xTaskCreatePinnedToCore(
      taskFunction,
      _taskName,
      _stackSize,
      context,
      _priority,
      &_taskHandle,
      _core
    );
  }

  template<typename T>
  void ManagedTask<T>::suspend() {
    if(_taskHandle != nullptr) {
      vTaskSuspend(_taskHandle);
    }
  }

  // Explizite Instanziierung für häufige Nutzung
  template class ManagedTask<class SystemMonitorTask>;
  template class ManagedTask<class NetworkHandlerTask>;
}