#pragma once
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

namespace uCore {
  template<typename T>
  class ManagedTask {
    public:
      ManagedTask(const char* name, uint16_t stackSize, UBaseType_t priority)
        : _taskName(name), _stackSize(stackSize), _priority(priority) {}
      
      void start(T* context) {
        xTaskCreate(
          taskFunction,
          _taskName,
          _stackSize,
          context,
          _priority,
          &_taskHandle
        );
      }
      
      void suspend() { vTaskSuspend(_taskHandle); }
      void resume() { vTaskResume(_taskHandle); }
      
      static void taskFunction(void* params) {
        T* context = static_cast<T*>(params);
        context->run();
      }
      
    private:
      TaskHandle_t _taskHandle;
      const char* _taskName;
      uint16_t _stackSize;
      UBaseType_t _priority;
  };
}