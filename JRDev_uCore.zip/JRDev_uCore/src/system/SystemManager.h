#pragma once
#include <Arduino.h>

namespace uCore {
  class SysCTL {
    public:
      enum class testENUM {
        NUM1,
        NUM2,
        NUM3
      };
      
      bool begin(bool systemDebug = false);
      
      // Hardware-Informationen
      static String getChipID();
      static String getRestartInfo();
      static String getCPUInfo();
      static String getNetworkInfo();
      static String getFlashInfo();
      static String getDevInfo();
      static String getVersions();
      
    private:
      bool _systemDebug = false;
  };
}