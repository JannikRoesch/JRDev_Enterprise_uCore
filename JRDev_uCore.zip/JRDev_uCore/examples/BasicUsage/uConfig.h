// WiFi-Zugangsdaten
#define WIFI_SSID "MeinNetzwerk"
#define WIFI_PASS "geheim123"

// OTA-Einstellungen
#define OTA_HOSTNAME "esp32-device"
#define OTA_PASSWORD "ota123"

// Systemeinstellungen
#define CPU_FREQUENCY 240
#define WATCHDOG_TIMEOUT 30