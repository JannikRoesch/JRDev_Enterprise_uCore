// Vollständige Konfiguration für Demozwecke
#include "../src/config/uConfigAdvanced.h"

// Gerätespezifische Overrides
#undef NET_WIFI_SSID
#define NET_WIFI_SSID "DemoNet"

#undef PERIPH_NEOPIXEL_COUNT
#define PERIPH_NEOPIXEL_COUNT 16

// Experimentelle Features
#define EXPERIMENTAL_BLE_MESH true
#define EXPERIMENTAL_WEBSERVER true