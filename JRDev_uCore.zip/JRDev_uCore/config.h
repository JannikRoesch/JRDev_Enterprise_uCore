#pragma once
// Feature-Toggles
#define FEATURE_WIFI 1
#define FEATURE_BLE 0
#define FEATURE_OTA 1