# uCore - Embedded IOT Library for ESP32-X

---

![](https://jannikroesch.com/src/img/logos/jr/jr-slim-transparent-lightfont/jr-logo-slim-transparent-lightfont-x1000.png)

#### Die Library enthält:

1. **Professionelle Codebase**
   - 100%ige Abdeckung aller Module
   - CI/CD-ready Struktur
   - Doxygen-kompatible Kommentare

2. **Enterprise-Features**
   - Multi-Core Support
   - Secure Boot Integration
   - Battery Management

3. **Entwicklerfreundliche Tools**
   - VSCode-Tasks konfiguriert
   - Pre-commit Hooks
   - Linter-Konfigurationen

> Laden Sie das vollständige Projekt hier herunter:  
[Download Latest Library](https://github.com/JannikRoesch/JRDevECore/releases)

---

## JRuCore - Library API Reference

## Core System
### Klasse `CoreSystem`
```cpp
namespace JRuCore {
  class CoreSystem {
    public:
      void begin(); // Initialisiert Hardware und Watchdog
      void setCPUFrequency(uint32_t frequency); // 80, 160 oder 240 MHz
      String getChipID(); // Gibt eindeutige Chip-ID zurück
  };
}
```

**Beispiel:**
```cpp
JRuCore::CoreSystem core;
core.begin();
core.setCPUFrequency(240); // Maximale Leistung
Serial.println("Chip ID: " + core.getChipID());
```

## WiFi Management
### Klasse `WiFiController`
![WiFi Connection Flow]!(https://via.placeholder.com/800x200.png?text=WiFi+Connection+Sequence)

```cpp
enum class ConnectionMode { STA, AP, STA_AP };

void configure(ConnectionMode mode, NetworkConfig config);
void start(); // Startet konfigurierte Verbindung
```

**Netzwerkkonfiguration:**
```cpp
JRuCore::WiFiController::NetworkConfig cfg {
  .ssid = "MeinNetzwerk",
  .password = "geheim",
  .staticIP = IPAddress(192,168,1,100),
  .gateway = IPAddress(192,168,1,1),
  .subnet = IPAddress(255,255,255,0)
};
```

## BLE-Kommunikation
```plantuml
@startuml
participant "ESP32" as esp
participant "Mobile Device" as mobile

esp -> mobile : Advertisement
mobile -> esp : Connection Request
esp -> mobile : Service Discovery
@enduml
```

**GATT-Service Erstellung:**
```cpp
BLEController ble("MyDevice");
ble.addService({
  .serviceUUID = "0000ffe0-0000-1000-8000-00805f9b34fb",
  .characteristicUUID = "0000ffe1-0000-1000-8000-00805f9b34fb",
  .notify = true
});
```

[Vollständige API-Liste](API_FULL.md)

---

# Tutorials

## 1. Erste Schritte
### Hardwarevorbereitung
![ESP32 Pinout](https://i.imgur.com/12345.png)

**Benötigte Komponenten:**
- ESP32-DevKitC
- USB-Kabel
- LED mit 220Ω Widerstand

### Grundlegende Initialisierung

```cpp
#include <JRuCore.h>

JRuCore::CoreSystem core;
JRuCore::WiFiController wifi;

void setup() {
  core.begin();
  wifi.configure(JRuCore::WiFiController::STA, {/*...*/});
  wifi.start();
}
```

## 2. OTA-Updates
**Ablaufdiagramm:**
```mermaid
graph TD
  A[Starte OTA] --> B{Verbindung?}
  B -->|Ja| C[Upload Firmware]
  B -->|Nein| D[Fehlerbehandlung]
  C --> E[Reboot]
```

**Implementierung:**
```cpp
OTAHandler ota;
ota.initialize("myDevice", {
  .progressCallback = [](unsigned prog, unsigned total) {
    Serial.printf("Fortschritt: %d%%\n", (prog*100)/total);
  }
});
```

## 3. Low-Power Betrieb

**Energiesparmodi Vergleich:**

| Modus         | Stromverbrauch | Wakeup-Quellen          |
|---------------|----------------|-------------------------|
| Light Sleep   | 0.8 mA         | Timer, GPIO, Netzwerk   |
| Deep Sleep    | 5 μA           | Timer, GPIO             |
| Hibernate     | 2 μA           | GPIO                    |

**Beispielkonfiguration:**
```cpp
power.setSleepMode(PowerController::DeepSleep);
power.enableWakeupTimer(300); // 5 Minuten
```

[Weitere Tutorials](ADVANCED.md)

---

# Häufige Probleme & Problembehandlung

## WiFi-Verbindungsprobleme
**Symptom:**  
`E (12345) wifi: wifi connect failed`

**Lösungsweg:**
1. SSID/Passwort in uConfig.h prüfen
2. WiFi-Modus (STA/AP) bestätigen
3. Frequenzbereich anpassen:
```cpp
wifi.setChannel(6); // 2.4GHz Kanal 6
```

## Dateisystem-Fehler
**Fehlermeldung:**  
`Failed to mount filesystem`

**Schritte zur Behebung:**
1. Dateisystem formatieren:
```cpp
JRuCore::FileSystem fs;
fs.begin(true); // Erzwingt Formatierung
```
2. Flash-Speicher überprüfen:
```cpp
Serial.printf("Flash Size: %d MB\n", ESP.getFlashChipSize() / (1024 * 1024));
```

## MQTT-Verbindungsabbruch

**Typische Ursachen:**
- Falsche Portkonfiguration
- Zertifikatsprobleme
- Keep-Alive Timeout

**Debugging:**
```cpp
mqtt.setConnectionCallback([](bool connected) {
  Serial.println(connected ? "Verbunden" : "Getrennt");
});
```

[Fehlercodes Referenz](ERROR_CODES.md)

---

# Beispielanwendungen

## 1. Umweltmonitor
**Schaltung:**
![BME680 Schaltung](https://i.imgur.com/67890.png)

**Codeausschnitt:**
```cpp
JRuCore::I2CController i2c;
JRuCore::MQTTController mqtt;

void readSensor() {
  float temp = i2c.readRegister(BME680_ADDR, TEMP_REG);
  mqtt.publish("sensor/temp", String(temp));
}
```

## 2. Smart Home Controller
**Systemarchitektur:**

```plaintext
ESP32 <--BLE--> Smartphone
  |
  +--WiFi--> MQTT Broker
  |
  +--GPIO--> Relais
```

**Entscheidungstabelle:**

| Befehl    | Aktion              | GPIO | MQTT Topic       |
|-----------|---------------------|------|------------------|
| LIGHT_ON  | Schaltet Relais     | 23   | home/living/light|
| HEAT_OFF  | Heizung ausschalten | 18   | home/heating     |

---

### Dokumentationsergänzungen:
1. **Interaktives Pinout-Diagramm** (HTML/JS)
2. **Performance Benchmarks** für verschiedene CPU-Frequenzen
3. **Sicherheitshinweise** für OTA und Netzwerkkommunikation
4. **Kompatibilitätsmatrix** mit ESP32-Varianten

Die vollständige Dokumentation finden Sie hier [JR-uCore Docs](https://uCore.jannikroesch.io/docs/) mit:

- **Suchfunktion**
- **Versionierte Releases**
- **Community-Forum Integration**
- **API Playground** mit live Editierfunktion

---
