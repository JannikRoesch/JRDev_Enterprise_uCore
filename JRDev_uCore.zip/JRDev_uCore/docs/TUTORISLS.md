# Tutorials

## 1. Erste Schritte
### Hardwarevorbereitung
![ESP32 Pinout](https://i.imgur.com/12345.png)

**Benötigte Komponenten:**
- ESP32-DevKitC
- USB-Kabel
- LED mit 220Ω Widerstand

### Grundlegende Initialisierung
```cpp
#include <JRDevECore.h>

JRDevECore::CoreSystem core;
JRDevECore::WiFiController wifi;

void setup() {
  core.begin();
  wifi.configure(JRDevECore::WiFiController::STA, {/*...*/});
  wifi.start();
}
```

## 2. OTA-Updates
**Ablaufdiagramm:**
```mermaid
graph TD
  A[Starte OTA] --> B{Verbindung?}
  B -->|Ja| C[Upload Firmware]
  B -->|Nein| D[Fehlerbehandlung]
  C --> E[Reboot]
```

**Implementierung:**
```cpp
OTAHandler ota;
ota.initialize("myDevice", {
  .progressCallback = [](unsigned prog, unsigned total) {
    Serial.printf("Fortschritt: %d%%\n", (prog*100)/total);
  }
});
```

## 3. Low-Power Betrieb
**Energiesparmodi Vergleich:**
| Modus         | Stromverbrauch | Wakeup-Quellen          |
|---------------|----------------|-------------------------|
| Light Sleep   | 0.8 mA         | Timer, GPIO, Netzwerk   |
| Deep Sleep    | 5 μA           | Timer, GPIO             |
| Hibernate     | 2 μA           | GPIO                    |

**Beispielkonfiguration:**
```cpp
power.setSleepMode(PowerController::DeepSleep);
power.enableWakeupTimer(300); // 5 Minuten
```

[Weitere Tutorials](ADVANCED.md)