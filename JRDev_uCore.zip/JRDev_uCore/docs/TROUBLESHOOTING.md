# Problembehandlung
```markdown
# Häufige Probleme & Lösungen

## WiFi-Verbindungsprobleme
**Symptom:**  
`E (12345) wifi: wifi connect failed`

**Lösungsweg:**
1. SSID/Passwort in uConfig.h prüfen
2. WiFi-Modus (STA/AP) bestätigen
3. Frequenzbereich anpassen:
```cpp
wifi.setChannel(6); // 2.4GHz Kanal 6
```

## Dateisystem-Fehler
**Fehlermeldung:**  
`Failed to mount filesystem`

**Schritte zur Behebung:**
1. Dateisystem formatieren:
```cpp
JRDevECore::FileSystem fs;
fs.begin(true); // Erzwingt Formatierung
```
2. Flash-Speicher überprüfen:
```cpp
Serial.printf("Flash Size: %d MB\n", ESP.getFlashChipSize() / (1024 * 1024));
```

## MQTT-Verbindungsabbruch
**Typische Ursachen:**
- Falsche Portkonfiguration
- Zertifikatsprobleme
- Keep-Alive Timeout

**Debugging:**
```cpp
mqtt.setConnectionCallback([](bool connected) {
  Serial.println(connected ? "Verbunden" : "Getrennt");
});
```

[Fehlercodes Referenz](ERROR_CODES.md)
```