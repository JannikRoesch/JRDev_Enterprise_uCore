# JRDevECore Library API Reference

## Core System
### Klasse `CoreSystem`
```cpp
namespace JRDevECore {
  class CoreSystem {
    public:
      void begin(); // Initialisiert Hardware und Watchdog
      void setCPUFrequency(uint32_t frequency); // 80, 160 oder 240 MHz
      String getChipID(); // Gibt eindeutige Chip-ID zurück
  };
}
```

**Beispiel:**
```cpp
JRDevECore::CoreSystem core;
core.begin();
core.setCPUFrequency(240); // Maximale Leistung
Serial.println("Chip ID: " + core.getChipID());
```

## WiFi Management
### Klasse `WiFiController`
![WiFi Connection Flow](https://via.placeholder.com/800x200.png?text=WiFi+Connection+Sequence)

```cpp
enum class ConnectionMode { STA, AP, STA_AP };

void configure(ConnectionMode mode, NetworkConfig config);
void start(); // Startet konfigurierte Verbindung
```

**Netzwerkkonfiguration:**
```cpp
JRDevECore::WiFiController::NetworkConfig cfg {
  .ssid = "MeinNetzwerk",
  .password = "geheim",
  .staticIP = IPAddress(192,168,1,100),
  .gateway = IPAddress(192,168,1,1),
  .subnet = IPAddress(255,255,255,0)
};
```

## BLE-Kommunikation
```plantuml
@startuml
participant "ESP32" as esp
participant "Mobile Device" as mobile

esp -> mobile : Advertisement
mobile -> esp : Connection Request
esp -> mobile : Service Discovery
@enduml
```

**GATT-Service Erstellung:**
```cpp
BLEController ble("MyDevice");
ble.addService({
  .serviceUUID = "0000ffe0-0000-1000-8000-00805f9b34fb",
  .characteristicUUID = "0000ffe1-0000-1000-8000-00805f9b34fb",
  .notify = true
});
```

[Vollständige API-Liste](API_FULL.md)