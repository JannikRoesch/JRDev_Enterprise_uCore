# Beispielanwendungen

## 1. Umweltmonitor
**Schaltung:**
![BME680 Schaltung](https://i.imgur.com/67890.png)

**Codeausschnitt:**
```cpp
JRDevECore::I2CController i2c;
JRDevECore::MQTTController mqtt;

void readSensor() {
  float temp = i2c.readRegister(BME680_ADDR, TEMP_REG);
  mqtt.publish("sensor/temp", String(temp));
}
```

## 2. Smart Home Controller
**Systemarchitektur:**
```plaintext
ESP32 <--BLE--> Smartphone
  |
  +--WiFi--> MQTT Broker
  |
  +--GPIO--> Relais
```

**Entscheidungstabelle:**
| Befehl    | Aktion           | GPIO | MQTT Topic       |
|-----------|------------------|------|------------------|
| LIGHT_ON  | Schaltet Relais  | 23   | home/living/light|
| HEAT_OFF  | Heizung ausschalten | 18 | home/heating     |
