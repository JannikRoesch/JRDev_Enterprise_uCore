```md
# Changelog

---

v1.0.1 - 2025-03-06
  - Renamed 'JRDevECore'to 'uCore'
  - Bug fixed & optimizations

---

v1.0.0 - 2025-03-1
  - Fixed: Memory leak in TaskManager.cpp
  - Added: Error handling in ConfigManager.cpp
  - Updated: WiFi reconnect logic in WiFiManager.cpp
  - Improved: BLE characteristic handling in BLEManager.cpp
  
---

v1.0.0
  - Init Commit
```